#!/usr/bin/env bash
set -Eeuo pipefail

REP="${1:-}"
if [[ ! "$REP" =~ ^r(0[1-9]|10)$ ]]; then
  echo "Usage: $0 r01|r02|r03|r04|r05|r06|r07|r08|r09|r10" >&2
  exit 2
fi

RUN="e3-mc4-aomqtt-fr-$REP"
EXP="e3-mc4-aomqtt"
TOPIC="e3/mc4/data"

BROKER="172.16.10.200"
PUB_SUFFIXES=(205 206 207 208 209)
SUB_SUFFIXES=(210 211 212 213 214)

SDK="$HOME/aomqtt-client-sdk-v1.3.7"
VENV="$HOME/aomqtt-client-sdk-v1.3.5/.venv"
POLICY="$HOME/aomqtt-experiment-config/e3-full-aomqtt.yaml"

RESULT="$HOME/aomqtt-results/$RUN"
ARCH="$HOME/aomqtt-experiment-archives/$RUN"

HEAD_EXPECT="6dc0b2c497098aca569a636d1f8f8bb2adc4253a"
POLICY_EXPECT="45bac842e7fe22b796129ba4e6c3c724b9f2495e8eb534af08dd674cef0a71cc"
SAMPLER_EXPECT="7eafb9726b40261083a6427a689e548ac3c788bc594233a806b8b3da8e2d66e2"

COUNT_PER_PUB=6000
INTERVAL=0.01
EXPECTED_TOTAL=$((5 * COUNT_PER_PUB))
TELEMETRY_DURATION=240

SCRIPT_REAL="$(readlink -f "$0")"
TMPDIR_MC4="$(mktemp -d)"
SUCCESS=0

say(){ printf '\n[%s] %s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" "$*"; }
fail(){ echo "ERROR: $*" >&2; exit 1; }

pub_ip(){
  local n="$1"
  echo "172.16.10.${PUB_SUFFIXES[$((n-1))]}"
}

sub_ip(){
  local n="$1"
  echo "172.16.10.${SUB_SUFFIXES[$((n-1))]}"
}

cleanup(){
  local rc=$?
  rm -rf "$TMPDIR_MC4" 2>/dev/null || true

  if [[ $SUCCESS -eq 1 || $rc -eq 0 ]]; then
    return
  fi

  echo >&2
  echo "Best-effort cleanup after failure..." >&2

  if [[ -d "$RESULT" ]]; then
    for f in publisher-1.pid publisher-1-proc-resource.pid publisher-1-vmstat.pid; do
      if [[ -f "$RESULT/$f" ]]; then
        kill "$(cat "$RESULT/$f")" 2>/dev/null || true
      fi
    done
  fi

  for n in 2 3 4 5; do
    ip="$(pub_ip "$n")"
    ssh ogawa@"$ip" "
      D=\$HOME/aomqtt-results/$RUN
      for f in publisher-$n.pid publisher-$n-proc-resource.pid publisher-$n-vmstat.pid; do
        test -f \$D/\$f && kill \$(cat \$D/\$f) 2>/dev/null || true
      done
    " >/dev/null 2>&1 || true
  done

  for n in 1 2 3 4 5; do
    ip="$(sub_ip "$n")"
    ssh ogawa@"$ip" "
      D=\$HOME/aomqtt-results/$RUN
      for f in subscriber-$n.pid subscriber-$n-proc-resource.pid subscriber-$n-vmstat.pid; do
        test -f \$D/\$f && kill \$(cat \$D/\$f) 2>/dev/null || true
      done
    " >/dev/null 2>&1 || true
  done

  ssh ogawa@"$BROKER" "
    D=\$HOME/aomqtt-results/$RUN
    for f in broker-proc-resource.pid broker-vmstat.pid; do
      test -f \$D/\$f && kill \$(cat \$D/\$f) 2>/dev/null || true
    done
  " >/dev/null 2>&1 || true
}
trap cleanup EXIT

say "preflight orchestrator / publisher-1"
[[ "$(hostname)" == "publisher-1" ]] || fail "run this script on publisher-1"

cd "$SDK"
source "$VENV/bin/activate"

[[ "$(git rev-parse HEAD)" == "$HEAD_EXPECT" ]] || fail "publisher-1 HEAD mismatch"
[[ "$(git describe --tags --exact-match HEAD)" == "v1.3.7" ]] || fail "publisher-1 tag mismatch"
[[ "$(sha256sum "$POLICY" | awk '{print $1}')" == "$POLICY_EXPECT" ]] || fail "publisher-1 policy SHA mismatch"
[[ "$(sha256sum "$HOME/proc_resource_sampler.py" | awk '{print $1}')" == "$SAMPLER_EXPECT" ]] || fail "publisher-1 sampler SHA mismatch"
[[ ! -e "$RESULT" ]] || fail "$RESULT exists"
[[ ! -e "$ARCH" ]] || fail "$ARCH exists"
[[ ! -e "$ARCH.tar.gz" ]] || fail "$ARCH.tar.gz exists"

say "preflight publisher-2..5"
for n in 2 3 4 5; do
  ip="$(pub_ip "$n")"
  ssh ogawa@"$ip" "
    set -e
    cd \$HOME/aomqtt-client-sdk-v1.3.7
    test ! -e \$HOME/aomqtt-results/$RUN
    test \"\$(git rev-parse HEAD)\" = '$HEAD_EXPECT'
    test \"\$(git describe --tags --exact-match HEAD)\" = 'v1.3.7'
    test \"\$(sha256sum \$HOME/aomqtt-experiment-config/e3-full-aomqtt.yaml | awk '{print \$1}')\" = '$POLICY_EXPECT'
    test \"\$(sha256sum \$HOME/proc_resource_sampler.py | awk '{print \$1}')\" = '$SAMPLER_EXPECT'
  "
  echo "publisher-$n preflight=PASS"
done

say "preflight subscribers 1..5"
for n in 1 2 3 4 5; do
  ip="$(sub_ip "$n")"
  ssh ogawa@"$ip" "
    set -e
    cd \$HOME/aomqtt-client-sdk-v1.3.7
    test ! -e \$HOME/aomqtt-results/$RUN
    test \"\$(git rev-parse HEAD)\" = '$HEAD_EXPECT'
    test \"\$(git describe --tags --exact-match HEAD)\" = 'v1.3.7'
    test \"\$(sha256sum \$HOME/aomqtt-experiment-config/e3-full-aomqtt.yaml | awk '{print \$1}')\" = '$POLICY_EXPECT'
    test \"\$(sha256sum \$HOME/proc_resource_sampler.py | awk '{print \$1}')\" = '$SAMPLER_EXPECT'
  "
  echo "subscriber-$n preflight=PASS"
done

say "preflight broker"
ssh ogawa@"$BROKER" "
  set -e
  test ! -e \$HOME/aomqtt-results/$RUN
  test \"\$(sha256sum \$HOME/proc_resource_sampler.py | awk '{print \$1}')\" = '$SAMPLER_EXPECT'
  pgrep -x mosquitto >/dev/null
"
echo "broker preflight=PASS"

say "start broker telemetry"
ssh ogawa@"$BROKER" "
  set -e
  mkdir -p \$HOME/aomqtt-results/$RUN
  D=\$HOME/aomqtt-results/$RUN
  M=\$(pgrep -x mosquitto | head -n1)
  echo \$M > \$D/mosquitto.pid
  sha256sum \$HOME/proc_resource_sampler.py > \$D/resource-sampler.sha256
  chronyc tracking > \$D/ntp-before.txt
  chronyc sources -v >> \$D/ntp-before.txt
  nohup python3 \$HOME/proc_resource_sampler.py \
    --output \$D/broker-proc-resource.csv \
    --interval 1 --duration $TELEMETRY_DURATION \
    --pid \$M --label broker-mosquitto \
    > \$D/broker-proc-resource.log 2>&1 < /dev/null &
  echo \$! > \$D/broker-proc-resource.pid
  nohup vmstat -t -w 1 $TELEMETRY_DURATION \
    > \$D/broker-vmstat.txt 2>&1 < /dev/null &
  echo \$! > \$D/broker-vmstat.pid
"

say "start subscribers 1..5"
for n in 1 2 3 4 5; do
  ip="$(sub_ip "$n")"

  ssh ogawa@"$ip" "
    set -e
    cd \$HOME/aomqtt-client-sdk-v1.3.7
    source \$HOME/aomqtt-client-sdk-v1.3.5/.venv/bin/activate

    D=\$HOME/aomqtt-results/$RUN
    mkdir -p \$D

    cp \$HOME/aomqtt-experiment-config/e3-full-aomqtt.yaml \$D/
    sha256sum \$D/e3-full-aomqtt.yaml > \$D/policy.sha256
    sha256sum \$HOME/proc_resource_sampler.py > \$D/resource-sampler.sha256
    git rev-parse HEAD > \$D/git-head.txt
    git describe --tags --exact-match HEAD > \$D/git-tag.txt
    chronyc tracking > \$D/ntp-before.txt
    chronyc sources -v >> \$D/ntp-before.txt

    nohup python -u examples/subscriber_example.py \
      --broker $BROKER --port 1883 \
      --client-id e3-mc4-sub$n \
      --config examples/config.example.yaml \
      --policy \$HOME/aomqtt-experiment-config/e3-full-aomqtt.yaml \
      --topic $TOPIC \
      --token-mode whole --qos 1 \
      --rotation --rotation-interval 30 --rotation-overlap 5 \
      --delivery-csv \$D/subscriber-$n-delivery.csv \
      --experiment-id $EXP --run-id $RUN \
      --save-experiment-config \
      --experiment-config-out \$D/subscriber-$n-config.json \
      > \$D/subscriber-$n.log 2>&1 < /dev/null &
    echo \$! > \$D/subscriber-$n.pid

    sleep 1

    nohup python3 \$HOME/proc_resource_sampler.py \
      --output \$D/subscriber-$n-proc-resource.csv \
      --interval 1 --duration $TELEMETRY_DURATION \
      --pid-file \$D/subscriber-$n.pid \
      --label subscriber-$n --stop-when-process-exits \
      > \$D/subscriber-$n-proc-resource.log 2>&1 < /dev/null &
    echo \$! > \$D/subscriber-$n-proc-resource.pid

    nohup vmstat -t -w 1 $TELEMETRY_DURATION \
      > \$D/subscriber-$n-vmstat.txt 2>&1 < /dev/null &
    echo \$! > \$D/subscriber-$n-vmstat.pid
  "
done

sleep 3

say "subscriber ready check"
for n in 1 2 3 4 5; do
  ip="$(sub_ip "$n")"

  ssh ogawa@"$ip" "
    set -e
    D=\$HOME/aomqtt-results/$RUN

    S=\$(cat \$D/subscriber-$n.pid)
    R=\$(cat \$D/subscriber-$n-proc-resource.pid)
    V=\$(cat \$D/subscriber-$n-vmstat.pid)

    kill -0 \$S
    kill -0 \$R
    kill -0 \$V

    echo subscriber-$n=READY
    grep '^\\^\\*' \$D/ntp-before.txt || true
  "
done

say "prepare publisher result directories"

mkdir -p "$RESULT"
cp "$POLICY" "$RESULT/"
sha256sum "$POLICY" > "$RESULT/policy.sha256"
sha256sum "$HOME/proc_resource_sampler.py" > "$RESULT/resource-sampler.sha256"
git rev-parse HEAD > "$RESULT/git-head.txt"
git describe --tags --exact-match HEAD > "$RESULT/git-tag.txt"
chronyc tracking > "$RESULT/ntp-before.txt"
chronyc sources -v >> "$RESULT/ntp-before.txt"
cp "$SCRIPT_REAL" "$RESULT/orchestration-script.sh"
sha256sum "$RESULT/orchestration-script.sh" > "$RESULT/orchestration-script.sha256"

for n in 2 3 4 5; do
  ip="$(pub_ip "$n")"
  ssh ogawa@"$ip" "
    set -e
    cd \$HOME/aomqtt-client-sdk-v1.3.7
    D=\$HOME/aomqtt-results/$RUN
    mkdir -p \$D
    cp \$HOME/aomqtt-experiment-config/e3-full-aomqtt.yaml \$D/
    sha256sum \$D/e3-full-aomqtt.yaml > \$D/policy.sha256
    sha256sum \$HOME/proc_resource_sampler.py > \$D/resource-sampler.sha256
    git rev-parse HEAD > \$D/git-head.txt
    git describe --tags --exact-match HEAD > \$D/git-tag.txt
    chronyc tracking > \$D/ntp-before.txt
    chronyc sources -v >> \$D/ntp-before.txt
  "
done

START_AT="$("$VENV/bin/python" - <<'PY'
import time
print(f"{time.time() + 45.0:.6f}")
PY
)"
START_ISO="$("$VENV/bin/python" - "$START_AT" <<'PY'
import datetime,sys
t=float(sys.argv[1])
print(datetime.datetime.fromtimestamp(t, datetime.timezone.utc).isoformat())
PY
)"

{
  echo "SCHEDULED_START_EPOCH=$START_AT"
  echo "SCHEDULED_START_UTC=$START_ISO"
} > "$RESULT/run-timing.txt"

say "build synchronized publisher wrappers"
for n in 1 2 3 4 5; do
  wrapper="$TMPDIR_MC4/publisher-$n-wrapper.sh"
  cat > "$wrapper" <<EOF
#!/usr/bin/env bash
set -Eeuo pipefail
START_AT="$START_AT"
delay=\$("$VENV/bin/python" -c "import time; print(max(0.0, float('$START_AT') - time.time()))")
sleep "\$delay"
cd "$SDK"
exec "$VENV/bin/python" -u examples/publisher_example.py \
  --broker $BROKER --port 1883 \
  --client-id e3-mc4-pub$n \
  --config examples/config.example.yaml \
  --policy "$POLICY" \
  --topic $TOPIC \
  --count $COUNT_PER_PUB --interval $INTERVAL \
  --pacing fixed-rate --qos 1 \
  --token-mode whole \
  --rotation --rotation-interval 30 --rotation-overlap 5 \
  --padding-mode fixed --padding-fixed-size 512 \
  --metrics-csv "\$HOME/aomqtt-results/$RUN/publisher-$n-metrics.csv" \
  --experiment-id $EXP --run-id $RUN \
  --save-experiment-config \
  --experiment-config-out "\$HOME/aomqtt-results/$RUN/publisher-$n-config.json"
EOF
  chmod +x "$wrapper"

  if [[ $n -eq 1 ]]; then
    cp "$wrapper" "$RESULT/publisher-1-wrapper.sh"
  else
    ip="$(pub_ip "$n")"
    scp "$wrapper" ogawa@"$ip":~/aomqtt-results/"$RUN"/publisher-"$n"-wrapper.sh
    ssh ogawa@"$ip" "chmod +x \$HOME/aomqtt-results/$RUN/publisher-$n-wrapper.sh"
  fi
done

say "launch publisher-1"
cd "$SDK"
nohup "$RESULT/publisher-1-wrapper.sh" \
  > "$RESULT/publisher-1.log" 2>&1 < /dev/null &
echo $! > "$RESULT/publisher-1.pid"

nohup python3 "$HOME/proc_resource_sampler.py" \
  --output "$RESULT/publisher-1-proc-resource.csv" \
  --interval 1 --duration "$TELEMETRY_DURATION" \
  --pid-file "$RESULT/publisher-1.pid" \
  --label publisher-1 --stop-when-process-exits \
  > "$RESULT/publisher-1-proc-resource.log" 2>&1 < /dev/null &
echo $! > "$RESULT/publisher-1-proc-resource.pid"

nohup vmstat -t -w 1 "$TELEMETRY_DURATION" \
  > "$RESULT/publisher-1-vmstat.txt" 2>&1 < /dev/null &
echo $! > "$RESULT/publisher-1-vmstat.pid"

say "launch publisher-2..5"
for n in 2 3 4 5; do
  ip="$(pub_ip "$n")"
  ssh ogawa@"$ip" "
    set -e
    D=\$HOME/aomqtt-results/$RUN

    nohup \$D/publisher-$n-wrapper.sh \
      > \$D/publisher-$n.log 2>&1 < /dev/null &
    echo \$! > \$D/publisher-$n.pid

    nohup python3 \$HOME/proc_resource_sampler.py \
      --output \$D/publisher-$n-proc-resource.csv \
      --interval 1 --duration $TELEMETRY_DURATION \
      --pid-file \$D/publisher-$n.pid \
      --label publisher-$n --stop-when-process-exits \
      > \$D/publisher-$n-proc-resource.log 2>&1 < /dev/null &
    echo \$! > \$D/publisher-$n-proc-resource.pid

    nohup vmstat -t -w 1 $TELEMETRY_DURATION \
      > \$D/publisher-$n-vmstat.txt 2>&1 < /dev/null &
    echo \$! > \$D/publisher-$n-vmstat.pid

    P=\$(cat \$D/publisher-$n.pid)
    kill -0 \$P
    echo publisher-$n=ARMED
  "
done

say "publisher armed check"
P1="$(cat "$RESULT/publisher-1.pid")"
kill -0 "$P1" || fail "publisher-1 wrapper not alive"
echo "publisher-1=ARMED"

for n in 2 3 4 5; do
  ip="$(pub_ip "$n")"
  ssh ogawa@"$ip" "
    P=\$(cat \$HOME/aomqtt-results/$RUN/publisher-$n.pid)
    kill -0 \$P
    echo publisher-$n=ARMED
  "
done

NOW="$("$VENV/bin/python" -c 'import time; print(time.time())')"
REMAIN="$("$VENV/bin/python" - "$START_AT" "$NOW" <<'PY'
import sys
print(float(sys.argv[1])-float(sys.argv[2]))
PY
)"
echo "scheduled_start_utc=$START_ISO"
echo "seconds_until_start=$REMAIN"

say "wait for synchronized run and completion"
"$VENV/bin/python" - "$START_AT" <<'PY'
import sys,time
target=float(sys.argv[1]) + 75.0
time.sleep(max(0.0, target-time.time()))
PY

alive=0
if kill -0 "$(cat "$RESULT/publisher-1.pid")" 2>/dev/null; then
  echo "publisher-1 still running after initial wait"
  alive=1
fi

for n in 2 3 4 5; do
  ip="$(pub_ip "$n")"
  if ssh ogawa@"$ip" "kill -0 \$(cat \$HOME/aomqtt-results/$RUN/publisher-$n.pid) 2>/dev/null"; then
    echo "publisher-$n still running after initial wait"
    alive=1
  fi
done

if [[ $alive -ne 0 ]]; then
  say "extra publisher drain wait"
  sleep 20
fi

kill -0 "$(cat "$RESULT/publisher-1.pid")" 2>/dev/null && fail "publisher-1 did not finish"
for n in 2 3 4 5; do
  ip="$(pub_ip "$n")"
  if ssh ogawa@"$ip" "kill -0 \$(cat \$HOME/aomqtt-results/$RUN/publisher-$n.pid) 2>/dev/null"; then
    fail "publisher-$n did not finish"
  fi
done

date -u '+PUBLISHERS_FINISHED_UTC=%Y-%m-%dT%H:%M:%SZ' | tee -a "$RESULT/run-timing.txt"

say "capture publisher post-run NTP and stop publisher vmstat"
chronyc tracking > "$RESULT/ntp-after.txt"
chronyc sources -v >> "$RESULT/ntp-after.txt"
kill "$(cat "$RESULT/publisher-1-vmstat.pid")" 2>/dev/null || true

for n in 2 3 4 5; do
  ip="$(pub_ip "$n")"
  ssh ogawa@"$ip" "
    D=\$HOME/aomqtt-results/$RUN
    chronyc tracking > \$D/ntp-after.txt
    chronyc sources -v >> \$D/ntp-after.txt
    kill \$(cat \$D/publisher-$n-vmstat.pid) 2>/dev/null || true
  "
done

sleep 2

say "stop subscribers 1..5"
for n in 1 2 3 4 5; do
  ip="$(sub_ip "$n")"

  ssh ogawa@"$ip" "
    D=\$HOME/aomqtt-results/$RUN
    S=\$(cat \$D/subscriber-$n.pid)

    kill -TERM \$S 2>/dev/null || true
    sleep 2

    kill -0 \$S 2>/dev/null \
      && kill -KILL \$S 2>/dev/null \
      || true

    chronyc tracking > \$D/ntp-after.txt
    chronyc sources -v >> \$D/ntp-after.txt

    for f in \
      subscriber-$n-proc-resource.pid \
      subscriber-$n-vmstat.pid
    do
      test -f \$D/\$f \
        && kill \$(cat \$D/\$f) 2>/dev/null \
        || true
    done
  "
done

say "stop broker telemetry"
ssh ogawa@"$BROKER" "
  D=\$HOME/aomqtt-results/$RUN
  chronyc tracking > \$D/ntp-after.txt
  chronyc sources -v >> \$D/ntp-after.txt
  for f in broker-proc-resource.pid broker-vmstat.pid; do
    test -f \$D/\$f && kill \$(cat \$D/\$f) 2>/dev/null || true
  done
"

date -u '+END_UTC=%Y-%m-%dT%H:%M:%SZ' | tee -a "$RESULT/run-timing.txt"

say "collect artifacts"

mkdir -p "$ARCH/broker-vm"
for n in 1 2 3 4 5; do
  mkdir -p \
    "$ARCH/publisher-$n" \
    "$ARCH/subscriber-$n"
done

cp -a "$RESULT"/. "$ARCH/publisher-1/"

for n in 2 3 4 5; do
  ip="$(pub_ip "$n")"
  scp -r \
    ogawa@"$ip":~/aomqtt-results/"$RUN"/. \
    "$ARCH/publisher-$n/"
done

for n in 1 2 3 4 5; do
  ip="$(sub_ip "$n")"
  scp -r \
    ogawa@"$ip":~/aomqtt-results/"$RUN"/. \
    "$ARCH/subscriber-$n/"
done

scp -r \
  ogawa@"$BROKER":~/aomqtt-results/"$RUN"/. \
  "$ARCH/broker-vm/"

say "quick validation"
python3 - "$ARCH" "$RUN" "$EXPECTED_TOTAL" <<'PY'
import csv
import math
import re
import statistics
import sys
from pathlib import Path

A=Path(sys.argv[1])
run=sys.argv[2]
expected_total=int(sys.argv[3])
ok=True

def truth(v):
    return str(v).strip().lower() in {"1","true","yes","y"}

def pct(values,q):
    xs=sorted(values)
    if not xs:
        return float("nan")
    k=(len(xs)-1)*q
    lo=int(math.floor(k))
    hi=min(lo+1,len(xs)-1)
    if lo==hi:
        return xs[lo]
    return xs[lo]+(xs[hi]-xs[lo])*(k-lo)

expected=set()
first_ts=[]

for n in range(1,6):
    p=A/f"publisher-{n}"/f"publisher-{n}-metrics.csv"
    with p.open(newline="") as f:
        rows=list(csv.DictReader(f))

    mids={r["message_id"] for r in rows if r.get("message_id")}
    exp={f"e3-mc4-pub{n}:{run}:{i}" for i in range(6000)}
    expected |= exp

    succ=sum(truth(r.get("success")) for r in rows)
    missing=len(exp-mids)
    unexpected=len(mids-exp)

    ts=[]
    for r in rows:
        try:
            ts.append(float(r.get("timestamp","")))
        except Exception:
            pass
    if ts:
        first_ts.append((n,min(ts)))

    log=(A/f"publisher-{n}"/f"publisher-{n}.log").read_text(errors="replace")
    m=re.search(r"pacing_deadline_miss:\s*(\d+)",log)
    misses=int(m.group(1)) if m else -1

    rp=A/f"publisher-{n}"/f"publisher-{n}-proc-resource.csv"
    rlines=sum(1 for _ in rp.open())

    print(
        f"publisher-{n}: physical_rows={len(rows)} unique={len(mids)} "
        f"success={succ} missing={missing} unexpected={unexpected} "
        f"pacing_deadline_miss={misses} resource_lines={rlines}"
    )

    ok &= (
        len(mids)==6000 and
        succ==len(rows) and
        missing==0 and
        unexpected==0 and
        misses==0 and
        rlines>=50
    )

print(f"expected_union={len(expected)}")
ok &= (len(expected)==expected_total)

subscriber_total_unique=0
subscriber_total_raw=0
subscriber_total_duplicates=0

for n in range(1,6):
    sp=A/f"subscriber-{n}"/f"subscriber-{n}-delivery.csv"

    with sp.open(newline="") as f:
        rows=list(csv.DictReader(f))

    good=[
        r for r in rows
        if truth(r.get("decrypt_success"))
    ]

    mids={
        r["message_id"]
        for r in good
        if r.get("message_id")
    }

    fail=len(rows)-len(good)
    missing=len(expected-mids)
    unexpected=len(mids-expected)
    duplicates=sum(
        truth(r.get("duplicate"))
        for r in good
    )

    lat=[]
    seen=set()

    for r in good:
        mid=r.get("message_id","")

        if (
            not mid
            or mid in seen
            or truth(r.get("duplicate"))
        ):
            continue

        seen.add(mid)

        try:
            v=float(r.get("delivery_latency_ms",""))
        except Exception:
            continue

        if v >= 0:
            lat.append(v)

    rp=(
        A/f"subscriber-{n}"
        /f"subscriber-{n}-proc-resource.csv"
    )

    subscriber_resource_lines=sum(
        1 for _ in rp.open()
    )

    print(
        f"subscriber-{n}: "
        f"raw={len(rows)} "
        f"unique={len(mids)} "
        f"duplicates={duplicates} "
        f"decrypt_fail={fail} "
        f"missing={missing} "
        f"unexpected={unexpected} "
        f"resource_lines={subscriber_resource_lines}"
    )

    ok &= (
        len(mids)==expected_total and
        fail==0 and
        missing==0 and
        unexpected==0 and
        duplicates>0 and
        subscriber_resource_lines>=50
    )

    if lat:
        print(
            f"subscriber-{n} latency_ms: "
            f"n={len(lat)} "
            f"mean={statistics.mean(lat):.6f} "
            f"p95={pct(lat,0.95):.6f} "
            f"p99={pct(lat,0.99):.6f} "
            f"max={max(lat):.6f}"
        )

    ok &= (len(lat)==expected_total)

    subscriber_total_unique += len(mids)
    subscriber_total_raw += len(rows)
    subscriber_total_duplicates += duplicates

print(
    "subscriber_all: "
    f"raw={subscriber_total_raw} "
    f"unique_observations={subscriber_total_unique} "
    f"duplicates={subscriber_total_duplicates}"
)

expected_subscriber_observations=5*expected_total

print(
    f"expected_subscriber_unique_observations="
    f"{expected_subscriber_observations}"
)

ok &= (
    subscriber_total_unique
    == expected_subscriber_observations
)

bp=A/"broker-vm"/"broker-proc-resource.csv"
broker_resource_lines=sum(1 for _ in bp.open())
print(f"broker_resource_lines={broker_resource_lines}")
ok &= broker_resource_lines>=50

if len(first_ts)==5:
    vals=[x[1] for x in first_ts]
    spread_ms=(max(vals)-min(vals))*1000.0
    print(f"publisher_first_metric_timestamp_spread_ms={spread_ms:.3f}")
else:
    print("publisher_first_metric_timestamp_spread_ms=NA")

print("QUICK_VALIDATION=" + ("PASS" if ok else "FAIL"))
sys.exit(0 if ok else 3)
PY

say "archive checksums"
cd "$ARCH"
find . -type f ! -name SHA256SUMS.txt ! -name SHA256SUMS.txt.sha256 -print0 \
  | sort -z | xargs -0 sha256sum > SHA256SUMS.txt
sha256sum SHA256SUMS.txt > SHA256SUMS.txt.sha256

cd "$HOME/aomqtt-experiment-archives"
tar -czf "$RUN.tar.gz" "$RUN"
sha256sum "$RUN.tar.gz" > "$RUN.tar.gz.sha256"

say "final"
for n in 1 2 3 4 5; do
  echo "===== publisher-$n summary ====="
  grep -E \
    "total MQTT messages:|success:|failed:|avg_complete_ms:|p95_complete_ms:|pacing_mode:|pacing_deadline_miss:|pacing_late_max_ms:" \
    "$ARCH/publisher-$n/publisher-$n.log" | tail -n 8 || true
done

for n in 1 2 3 4 5; do
  echo "===== subscriber-$n summary ====="
  tail -n 12 \
    "$ARCH/subscriber-$n/subscriber-$n.log" \
    || true
done

echo "===== timing ====="
cat "$RESULT/run-timing.txt"

echo "===== archive SHA256 ====="
cat "$HOME/aomqtt-experiment-archives/$RUN.tar.gz.sha256"

SUCCESS=1
echo "MC4 Full AOMQTT $REP completed"

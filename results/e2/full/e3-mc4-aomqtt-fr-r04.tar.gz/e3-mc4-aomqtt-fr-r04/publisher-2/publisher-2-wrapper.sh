#!/usr/bin/env bash
set -Eeuo pipefail
START_AT="1790434246.205922"
delay=$("/home/ogawa/aomqtt-client-sdk-v1.3.5/.venv/bin/python" -c "import time; print(max(0.0, float('1790434246.205922') - time.time()))")
sleep "$delay"
cd "/home/ogawa/aomqtt-client-sdk-v1.3.7"
exec "/home/ogawa/aomqtt-client-sdk-v1.3.5/.venv/bin/python" -u examples/publisher_example.py   --broker 172.16.10.200 --port 1883   --client-id e3-mc4-pub2   --config examples/config.example.yaml   --policy "/home/ogawa/aomqtt-experiment-config/e3-full-aomqtt.yaml"   --topic e3/mc4/data   --count 6000 --interval 0.01   --pacing fixed-rate --qos 1   --token-mode whole   --rotation --rotation-interval 30 --rotation-overlap 5   --padding-mode fixed --padding-fixed-size 512   --metrics-csv "$HOME/aomqtt-results/e3-mc4-aomqtt-fr-r04/publisher-2-metrics.csv"   --experiment-id e3-mc4-aomqtt --run-id e3-mc4-aomqtt-fr-r04   --save-experiment-config   --experiment-config-out "$HOME/aomqtt-results/e3-mc4-aomqtt-fr-r04/publisher-2-config.json"

#!/usr/bin/env bash
set -Eeuo pipefail
START_AT="1790483116.633807"
delay=$("/home/ogawa/aomqtt-client-sdk-v1.3.5/.venv/bin/python" -c "import time; print(max(0.0, float('1790483116.633807') - time.time()))")
sleep "$delay"
exec "/home/ogawa/aomqtt-client-sdk-v1.3.5/.venv/bin/python" -u "/home/ogawa/aomqtt-e3-tools/e3_plain_publisher.py"   --broker 172.16.10.200 --port 1883   --topic e3/mc4/data   --count 6000 --interval 0.01   --pacing fixed-rate --qos 1   --client-id e3-mc4-plain-pub3   --experiment-id e3-mc4-plain --run-id e3-mc4-plain-fr-r07   --metrics-csv "$HOME/aomqtt-results/e3-mc4-plain-fr-r07/publisher-3-metrics.csv"

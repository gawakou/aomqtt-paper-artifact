#!/usr/bin/env bash
set -Eeuo pipefail

REP="${1:-}"
if [[ ! "$REP" =~ ^r(0[1-9]|10)$ ]]; then
  echo "Usage: $0 r01|r02|r03|r04|r05|r06|r07|r08|r09|r10" >&2
  exit 2
fi

RUN="e3-mc4-plain-fr-$REP"
EXP="e3-mc4-plain"
TOPIC="e3/mc4/data"

BROKER="172.16.10.200"
PUB_SUFFIXES=(205 206 207 208 209)
SUB_SUFFIXES=(210 211 212 213 214)

SDK="$HOME/aomqtt-client-sdk-v1.3.7"
VENV="$HOME/aomqtt-client-sdk-v1.3.5/.venv"
PY="$VENV/bin/python"
TOOLS="$HOME/aomqtt-e3-tools"
PUB="$TOOLS/e3_plain_publisher.py"
SUB="$TOOLS/e3_plain_subscriber.py"
SAMPLER="$HOME/proc_resource_sampler.py"

RESULT="$HOME/aomqtt-results/$RUN"
ARCH="$HOME/aomqtt-experiment-archives/$RUN"

HEAD_EXPECT="6dc0b2c497098aca569a636d1f8f8bb2adc4253a"
PUB_EXPECT="3631cb8464e1cfda040fd933abe01c95b4877a3c739603c2525e525913f71a51"
SUB_EXPECT="8944f642d8012946839fb2b0b36b0ca2bc133f76c4f071731b9174b1c31803ec"
SAMPLER_EXPECT="7eafb9726b40261083a6427a689e548ac3c788bc594233a806b8b3da8e2d66e2"
PAHO_EXPECT="2.1.0"

CLIENT_KERNEL_EXPECT="6.8.0-139-generic"
BROKER_KERNEL_EXPECT="6.8.0-138-generic"

COUNT_PER_PUB=6000
INTERVAL=0.01
EXPECTED_TOTAL=$((5 * COUNT_PER_PUB))
EXPECTED_OBSERVATIONS=$((5 * EXPECTED_TOTAL))
TELEMETRY_DURATION=240
SUB_TIMEOUT=180

SCRIPT_REAL="$(readlink -f "$0")"
TMPDIR_MC4="$(mktemp -d)"
SUCCESS=0

say(){ printf '\n[%s] %s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" "$*"; }
fail(){ echo "ERROR: $*" >&2; exit 1; }

pub_ip(){
  local n="$1"
  echo "172.16.10.${PUB_SUFFIXES[$((n-1))]}"
}

sub_ip(){
  local n="$1"
  echo "172.16.10.${SUB_SUFFIXES[$((n-1))]}"
}

cleanup(){
  local rc=$?
  rm -rf "$TMPDIR_MC4" 2>/dev/null || true

  if [[ $SUCCESS -eq 1 || $rc -eq 0 ]]; then
    return
  fi

  echo >&2
  echo "Best-effort cleanup after failure..." >&2

  if [[ -d "$RESULT" ]]; then
    for f in publisher-1.pid publisher-1-proc-resource.pid publisher-1-vmstat.pid; do
      if [[ -f "$RESULT/$f" ]]; then
        kill "$(cat "$RESULT/$f")" 2>/dev/null || true
      fi
    done
  fi

  for n in 2 3 4 5; do
    ip="$(pub_ip "$n")"
    ssh ogawa@"$ip" "
      D=\$HOME/aomqtt-results/$RUN
      for f in publisher-$n.pid publisher-$n-proc-resource.pid publisher-$n-vmstat.pid; do
        test -f \$D/\$f && kill \$(cat \$D/\$f) 2>/dev/null || true
      done
    " >/dev/null 2>&1 || true
  done

  for n in 1 2 3 4 5; do
    ip="$(sub_ip "$n")"
    ssh ogawa@"$ip" "
      D=\$HOME/aomqtt-results/$RUN
      for f in subscriber-$n.pid subscriber-$n-proc-resource.pid subscriber-$n-vmstat.pid; do
        test -f \$D/\$f && kill \$(cat \$D/\$f) 2>/dev/null || true
      done
    " >/dev/null 2>&1 || true
  done

  ssh ogawa@"$BROKER" "
    D=\$HOME/aomqtt-results/$RUN
    for f in broker-proc-resource.pid broker-vmstat.pid; do
      test -f \$D/\$f && kill \$(cat \$D/\$f) 2>/dev/null || true
    done
  " >/dev/null 2>&1 || true
}
trap cleanup EXIT

say "preflight orchestrator / publisher-1"
[[ "$(hostname)" == "publisher-1" ]] || fail "run this script on publisher-1"
[[ "$(uname -r)" == "$CLIENT_KERNEL_EXPECT" ]] || fail "publisher-1 kernel mismatch"

cd "$SDK"
[[ -x "$PY" ]] || fail "publisher-1 venv python missing"
[[ "$(git rev-parse HEAD)" == "$HEAD_EXPECT" ]] || fail "publisher-1 HEAD mismatch"
[[ "$(git describe --tags --exact-match HEAD)" == "v1.3.7" ]] || fail "publisher-1 tag mismatch"
[[ "$(sha256sum "$PUB" | awk '{print $1}')" == "$PUB_EXPECT" ]] || fail "publisher-1 plain publisher SHA mismatch"
[[ "$(sha256sum "$SUB" | awk '{print $1}')" == "$SUB_EXPECT" ]] || fail "publisher-1 plain subscriber SHA mismatch"
[[ "$(sha256sum "$SAMPLER" | awk '{print $1}')" == "$SAMPLER_EXPECT" ]] || fail "publisher-1 sampler SHA mismatch"
[[ "$($PY -c 'import importlib.metadata; print(importlib.metadata.version("paho-mqtt"))')" == "$PAHO_EXPECT" ]] || fail "publisher-1 paho-mqtt version mismatch"
"$PY" -m py_compile "$PUB" "$SUB"
[[ ! -e "$RESULT" ]] || fail "$RESULT exists"
[[ ! -e "$ARCH" ]] || fail "$ARCH exists"
[[ ! -e "$ARCH.tar.gz" ]] || fail "$ARCH.tar.gz exists"
echo "publisher-1 preflight=PASS"

say "preflight publisher-2..5"
for n in 2 3 4 5; do
  ip="$(pub_ip "$n")"
  ssh ogawa@"$ip" "
    set -e
    test \"\$(uname -r)\" = '$CLIENT_KERNEL_EXPECT'
    cd \$HOME/aomqtt-client-sdk-v1.3.7
    test ! -e \$HOME/aomqtt-results/$RUN
    test \"\$(git rev-parse HEAD)\" = '$HEAD_EXPECT'
    test \"\$(git describe --tags --exact-match HEAD)\" = 'v1.3.7'
    test \"\$(sha256sum \$HOME/aomqtt-e3-tools/e3_plain_publisher.py | awk '{print \$1}')\" = '$PUB_EXPECT'
    test \"\$(sha256sum \$HOME/proc_resource_sampler.py | awk '{print \$1}')\" = '$SAMPLER_EXPECT'
    test \"\$(\$HOME/aomqtt-client-sdk-v1.3.5/.venv/bin/python -c 'import importlib.metadata; print(importlib.metadata.version(\"paho-mqtt\"))')\" = '$PAHO_EXPECT'
    \$HOME/aomqtt-client-sdk-v1.3.5/.venv/bin/python -m py_compile \$HOME/aomqtt-e3-tools/e3_plain_publisher.py
  "
  echo "publisher-$n preflight=PASS"
done

say "preflight subscribers 1..5"
for n in 1 2 3 4 5; do
  ip="$(sub_ip "$n")"
  ssh ogawa@"$ip" "
    set -e
    test \"\$(uname -r)\" = '$CLIENT_KERNEL_EXPECT'
    cd \$HOME/aomqtt-client-sdk-v1.3.7
    test ! -e \$HOME/aomqtt-results/$RUN
    test \"\$(git rev-parse HEAD)\" = '$HEAD_EXPECT'
    test \"\$(git describe --tags --exact-match HEAD)\" = 'v1.3.7'
    test \"\$(sha256sum \$HOME/aomqtt-e3-tools/e3_plain_subscriber.py | awk '{print \$1}')\" = '$SUB_EXPECT'
    test \"\$(sha256sum \$HOME/proc_resource_sampler.py | awk '{print \$1}')\" = '$SAMPLER_EXPECT'
    test \"\$(\$HOME/aomqtt-client-sdk-v1.3.5/.venv/bin/python -c 'import importlib.metadata; print(importlib.metadata.version(\"paho-mqtt\"))')\" = '$PAHO_EXPECT'
    \$HOME/aomqtt-client-sdk-v1.3.5/.venv/bin/python -m py_compile \$HOME/aomqtt-e3-tools/e3_plain_subscriber.py
  "
  echo "subscriber-$n preflight=PASS"
done

say "preflight broker"
ssh ogawa@"$BROKER" "
  set -e
  test \"\$(uname -r)\" = '$BROKER_KERNEL_EXPECT'
  test ! -e \$HOME/aomqtt-results/$RUN
  test \"\$(sha256sum \$HOME/proc_resource_sampler.py | awk '{print \$1}')\" = '$SAMPLER_EXPECT'
  pgrep -x mosquitto >/dev/null
"
echo "broker preflight=PASS"

say "start broker telemetry"
ssh ogawa@"$BROKER" "
  set -e
  mkdir -p \$HOME/aomqtt-results/$RUN
  D=\$HOME/aomqtt-results/$RUN
  M=\$(pgrep -x mosquitto | head -n1)
  echo \$M > \$D/mosquitto.pid
  sha256sum \$HOME/proc_resource_sampler.py > \$D/resource-sampler.sha256
  mosquitto -h 2>&1 | head -n1 > \$D/mosquitto-version.txt || true
  chronyc tracking > \$D/ntp-before.txt
  chronyc sources -v >> \$D/ntp-before.txt

  nohup python3 \$HOME/proc_resource_sampler.py \
    --output \$D/broker-proc-resource.csv \
    --interval 1 --duration $TELEMETRY_DURATION \
    --pid \$M --label broker-mosquitto \
    > \$D/broker-proc-resource.log 2>&1 < /dev/null &
  echo \$! > \$D/broker-proc-resource.pid

  nohup vmstat -t -w 1 $TELEMETRY_DURATION \
    > \$D/broker-vmstat.txt 2>&1 < /dev/null &
  echo \$! > \$D/broker-vmstat.pid
"

say "start subscribers 1..5"
for n in 1 2 3 4 5; do
  ip="$(sub_ip "$n")"
  ssh ogawa@"$ip" "
    set -e
    D=\$HOME/aomqtt-results/$RUN
    mkdir -p \$D
    rm -f \$D/subscriber-$n.ready

    sha256sum \$HOME/aomqtt-e3-tools/e3_plain_subscriber.py > \$D/plain-subscriber.sha256
    sha256sum \$HOME/proc_resource_sampler.py > \$D/resource-sampler.sha256
    cd \$HOME/aomqtt-client-sdk-v1.3.7
    git rev-parse HEAD > \$D/git-head.txt
    git describe --tags --exact-match HEAD > \$D/git-tag.txt
    \$HOME/aomqtt-client-sdk-v1.3.5/.venv/bin/python --version > \$D/python-version.txt 2>&1
    \$HOME/aomqtt-client-sdk-v1.3.5/.venv/bin/python -c 'import importlib.metadata; print(importlib.metadata.version(\"paho-mqtt\"))' > \$D/paho-version.txt
    chronyc tracking > \$D/ntp-before.txt
    chronyc sources -v >> \$D/ntp-before.txt

    printf '%s\n' \
      'experiment_id=$EXP' \
      'run_id=$RUN' \
      'role=subscriber-$n' \
      'broker=$BROKER:1883' \
      'topic=$TOPIC' \
      'qos=1' \
      'target_unique=$EXPECTED_TOTAL' \
      'timeout_s=$SUB_TIMEOUT' \
      'drain_seconds=1.0' \
      'client_id=e3-mc4-plain-sub$n' \
      'security=plain-mqtt-no-tokenization-no-encryption-no-padding-no-rotation' \
      > \$D/run-config.txt

    nohup \$HOME/aomqtt-client-sdk-v1.3.5/.venv/bin/python -u \
      \$HOME/aomqtt-e3-tools/e3_plain_subscriber.py \
      --broker $BROKER --port 1883 --topic $TOPIC \
      --count $EXPECTED_TOTAL --qos 1 \
      --client-id e3-mc4-plain-sub$n \
      --experiment-id $EXP --run-id $RUN \
      --metrics-csv \$D/subscriber-$n-delivery.csv \
      --ready-file \$D/subscriber-$n.ready \
      --timeout $SUB_TIMEOUT --drain-seconds 1.0 \
      > \$D/subscriber-$n.log 2>&1 < /dev/null &
    echo \$! > \$D/subscriber-$n.pid

    sleep 1

    nohup python3 \$HOME/proc_resource_sampler.py \
      --output \$D/subscriber-$n-proc-resource.csv \
      --interval 1 --duration $TELEMETRY_DURATION \
      --pid-file \$D/subscriber-$n.pid \
      --label subscriber-$n --stop-when-process-exits \
      > \$D/subscriber-$n-proc-resource.log 2>&1 < /dev/null &
    echo \$! > \$D/subscriber-$n-proc-resource.pid

    nohup vmstat -t -w 1 $TELEMETRY_DURATION \
      > \$D/subscriber-$n-vmstat.txt 2>&1 < /dev/null &
    echo \$! > \$D/subscriber-$n-vmstat.pid
  "
done

sleep 2

say "subscriber ready check"
for n in 1 2 3 4 5; do
  ip="$(sub_ip "$n")"
  ready=0
  for _ in $(seq 1 20); do
    if ssh ogawa@"$ip" "test -s \$HOME/aomqtt-results/$RUN/subscriber-$n.ready"; then
      ready=1
      break
    fi
    sleep 0.5
  done
  [[ $ready -eq 1 ]] || fail "subscriber-$n did not become READY"

  ssh ogawa@"$ip" "
    D=\$HOME/aomqtt-results/$RUN
    S=\$(cat \$D/subscriber-$n.pid)
    R=\$(cat \$D/subscriber-$n-proc-resource.pid)
    V=\$(cat \$D/subscriber-$n-vmstat.pid)
    kill -0 \$S
    kill -0 \$R
    kill -0 \$V
    echo subscriber-$n=READY
    cat \$D/subscriber-$n.ready
    grep '^\\^\\*' \$D/ntp-before.txt || true
  "
done

say "prepare publisher result directories"

mkdir -p "$RESULT"
sha256sum "$PUB" > "$RESULT/plain-publisher.sha256"
sha256sum "$SUB" > "$RESULT/plain-subscriber.sha256"
sha256sum "$SAMPLER" > "$RESULT/resource-sampler.sha256"
cd "$SDK"
git rev-parse HEAD > "$RESULT/git-head.txt"
git describe --tags --exact-match HEAD > "$RESULT/git-tag.txt"
"$PY" --version > "$RESULT/python-version.txt" 2>&1
"$PY" -c 'import importlib.metadata; print(importlib.metadata.version("paho-mqtt"))' > "$RESULT/paho-version.txt"
chronyc tracking > "$RESULT/ntp-before.txt"
chronyc sources -v >> "$RESULT/ntp-before.txt"
cp "$SCRIPT_REAL" "$RESULT/orchestration-script.sh"
sha256sum "$RESULT/orchestration-script.sh" > "$RESULT/orchestration-script.sha256"

printf '%s\n' \
  "experiment_id=$EXP" \
  "run_id=$RUN" \
  "role=publisher-1" \
  "broker=$BROKER:1883" \
  "topic=$TOPIC" \
  "qos=1" \
  "logical_messages=$COUNT_PER_PUB" \
  "interval_s=$INTERVAL" \
  "pacing=fixed-rate" \
  "client_id=e3-mc4-plain-pub1" \
  "security=plain-mqtt-no-tokenization-no-encryption-no-padding-no-rotation" \
  > "$RESULT/run-config.txt"

for n in 2 3 4 5; do
  ip="$(pub_ip "$n")"
  ssh ogawa@"$ip" "
    set -e
    D=\$HOME/aomqtt-results/$RUN
    mkdir -p \$D
    sha256sum \$HOME/aomqtt-e3-tools/e3_plain_publisher.py > \$D/plain-publisher.sha256
    sha256sum \$HOME/proc_resource_sampler.py > \$D/resource-sampler.sha256
    cd \$HOME/aomqtt-client-sdk-v1.3.7
    git rev-parse HEAD > \$D/git-head.txt
    git describe --tags --exact-match HEAD > \$D/git-tag.txt
    \$HOME/aomqtt-client-sdk-v1.3.5/.venv/bin/python --version > \$D/python-version.txt 2>&1
    \$HOME/aomqtt-client-sdk-v1.3.5/.venv/bin/python -c 'import importlib.metadata; print(importlib.metadata.version(\"paho-mqtt\"))' > \$D/paho-version.txt
    chronyc tracking > \$D/ntp-before.txt
    chronyc sources -v >> \$D/ntp-before.txt

    printf '%s\n' \
      'experiment_id=$EXP' \
      'run_id=$RUN' \
      'role=publisher-$n' \
      'broker=$BROKER:1883' \
      'topic=$TOPIC' \
      'qos=1' \
      'logical_messages=$COUNT_PER_PUB' \
      'interval_s=$INTERVAL' \
      'pacing=fixed-rate' \
      'client_id=e3-mc4-plain-pub$n' \
      'security=plain-mqtt-no-tokenization-no-encryption-no-padding-no-rotation' \
      > \$D/run-config.txt
  "
done

START_AT="$("$PY" - <<'PY'
import time
print(f"{time.time() + 45.0:.6f}")
PY
)"

START_ISO="$("$PY" - "$START_AT" <<'PY'
import datetime, sys
t=float(sys.argv[1])
print(datetime.datetime.fromtimestamp(t, datetime.timezone.utc).isoformat())
PY
)"

{
  echo "SCHEDULED_START_EPOCH=$START_AT"
  echo "SCHEDULED_START_UTC=$START_ISO"
} > "$RESULT/run-timing.txt"

say "build synchronized publisher wrappers"
for n in 1 2 3 4 5; do
  wrapper="$TMPDIR_MC4/publisher-$n-wrapper.sh"
  cat > "$wrapper" <<EOF
#!/usr/bin/env bash
set -Eeuo pipefail
START_AT="$START_AT"
delay=\$("$VENV/bin/python" -c "import time; print(max(0.0, float('$START_AT') - time.time()))")
sleep "\$delay"
exec "$VENV/bin/python" -u "$PUB" \
  --broker $BROKER --port 1883 \
  --topic $TOPIC \
  --count $COUNT_PER_PUB --interval $INTERVAL \
  --pacing fixed-rate --qos 1 \
  --client-id e3-mc4-plain-pub$n \
  --experiment-id $EXP --run-id $RUN \
  --metrics-csv "\$HOME/aomqtt-results/$RUN/publisher-$n-metrics.csv"
EOF
  chmod +x "$wrapper"

  if [[ $n -eq 1 ]]; then
    cp "$wrapper" "$RESULT/publisher-1-wrapper.sh"
  else
    ip="$(pub_ip "$n")"
    scp "$wrapper" ogawa@"$ip":~/aomqtt-results/"$RUN"/publisher-"$n"-wrapper.sh
    ssh ogawa@"$ip" "chmod +x \$HOME/aomqtt-results/$RUN/publisher-$n-wrapper.sh"
  fi
done

say "launch publisher-1"
nohup "$RESULT/publisher-1-wrapper.sh" \
  > "$RESULT/publisher-1.log" 2>&1 < /dev/null &
echo $! > "$RESULT/publisher-1.pid"

nohup python3 "$SAMPLER" \
  --output "$RESULT/publisher-1-proc-resource.csv" \
  --interval 1 --duration "$TELEMETRY_DURATION" \
  --pid-file "$RESULT/publisher-1.pid" \
  --label publisher-1 --stop-when-process-exits \
  > "$RESULT/publisher-1-proc-resource.log" 2>&1 < /dev/null &
echo $! > "$RESULT/publisher-1-proc-resource.pid"

nohup vmstat -t -w 1 "$TELEMETRY_DURATION" \
  > "$RESULT/publisher-1-vmstat.txt" 2>&1 < /dev/null &
echo $! > "$RESULT/publisher-1-vmstat.pid"

say "launch publisher-2..5"
for n in 2 3 4 5; do
  ip="$(pub_ip "$n")"
  ssh ogawa@"$ip" "
    set -e
    D=\$HOME/aomqtt-results/$RUN

    nohup \$D/publisher-$n-wrapper.sh \
      > \$D/publisher-$n.log 2>&1 < /dev/null &
    echo \$! > \$D/publisher-$n.pid

    nohup python3 \$HOME/proc_resource_sampler.py \
      --output \$D/publisher-$n-proc-resource.csv \
      --interval 1 --duration $TELEMETRY_DURATION \
      --pid-file \$D/publisher-$n.pid \
      --label publisher-$n --stop-when-process-exits \
      > \$D/publisher-$n-proc-resource.log 2>&1 < /dev/null &
    echo \$! > \$D/publisher-$n-proc-resource.pid

    nohup vmstat -t -w 1 $TELEMETRY_DURATION \
      > \$D/publisher-$n-vmstat.txt 2>&1 < /dev/null &
    echo \$! > \$D/publisher-$n-vmstat.pid

    P=\$(cat \$D/publisher-$n.pid)
    kill -0 \$P
    echo publisher-$n=ARMED
  "
done

say "publisher armed check"
P1="$(cat "$RESULT/publisher-1.pid")"
kill -0 "$P1" || fail "publisher-1 wrapper not alive"
echo "publisher-1=ARMED"

for n in 2 3 4 5; do
  ip="$(pub_ip "$n")"
  ssh ogawa@"$ip" "
    P=\$(cat \$HOME/aomqtt-results/$RUN/publisher-$n.pid)
    kill -0 \$P
    echo publisher-$n=ARMED
  "
done

NOW="$("$PY" -c 'import time; print(time.time())')"
REMAIN="$("$PY" - "$START_AT" "$NOW" <<'PY'
import sys
print(float(sys.argv[1]) - float(sys.argv[2]))
PY
)"

echo "scheduled_start_utc=$START_ISO"
echo "seconds_until_start=$REMAIN"

"$PY" - "$REMAIN" <<'PY'
import sys
r=float(sys.argv[1])
if r <= 0:
    raise SystemExit("scheduled start is not in the future")
PY

say "wait for synchronized run and completion"
"$PY" - "$START_AT" <<'PY'
import sys, time
target=float(sys.argv[1]) + 75.0
time.sleep(max(0.0, target-time.time()))
PY

alive=0
if kill -0 "$(cat "$RESULT/publisher-1.pid")" 2>/dev/null; then
  echo "publisher-1 still running after initial wait"
  alive=1
fi

for n in 2 3 4 5; do
  ip="$(pub_ip "$n")"
  if ssh ogawa@"$ip" "kill -0 \$(cat \$HOME/aomqtt-results/$RUN/publisher-$n.pid) 2>/dev/null"; then
    echo "publisher-$n still running after initial wait"
    alive=1
  fi
done

if [[ $alive -ne 0 ]]; then
  say "extra publisher drain wait"
  sleep 20
fi

kill -0 "$(cat "$RESULT/publisher-1.pid")" 2>/dev/null && fail "publisher-1 did not finish"
for n in 2 3 4 5; do
  ip="$(pub_ip "$n")"
  if ssh ogawa@"$ip" "kill -0 \$(cat \$HOME/aomqtt-results/$RUN/publisher-$n.pid) 2>/dev/null"; then
    fail "publisher-$n did not finish"
  fi
done

date -u '+PUBLISHERS_FINISHED_UTC=%Y-%m-%dT%H:%M:%SZ' | tee -a "$RESULT/run-timing.txt"

say "capture publisher post-run NTP and stop publisher vmstat"
chronyc tracking > "$RESULT/ntp-after.txt"
chronyc sources -v >> "$RESULT/ntp-after.txt"
kill "$(cat "$RESULT/publisher-1-vmstat.pid")" 2>/dev/null || true

for n in 2 3 4 5; do
  ip="$(pub_ip "$n")"
  ssh ogawa@"$ip" "
    D=\$HOME/aomqtt-results/$RUN
    chronyc tracking > \$D/ntp-after.txt
    chronyc sources -v >> \$D/ntp-after.txt
    kill \$(cat \$D/publisher-$n-vmstat.pid) 2>/dev/null || true
  "
done

sleep 2

say "stop subscribers 1..5"
for n in 1 2 3 4 5; do
  ip="$(sub_ip "$n")"
  ssh ogawa@"$ip" "
    D=\$HOME/aomqtt-results/$RUN
    S=\$(cat \$D/subscriber-$n.pid)
    kill -TERM \$S 2>/dev/null || true
    sleep 2
    kill -0 \$S 2>/dev/null && kill -KILL \$S 2>/dev/null || true

    chronyc tracking > \$D/ntp-after.txt
    chronyc sources -v >> \$D/ntp-after.txt

    for f in subscriber-$n-proc-resource.pid subscriber-$n-vmstat.pid; do
      test -f \$D/\$f && kill \$(cat \$D/\$f) 2>/dev/null || true
    done
  "
done

say "stop broker telemetry"
ssh ogawa@"$BROKER" "
  D=\$HOME/aomqtt-results/$RUN
  chronyc tracking > \$D/ntp-after.txt
  chronyc sources -v >> \$D/ntp-after.txt
  for f in broker-proc-resource.pid broker-vmstat.pid; do
    test -f \$D/\$f && kill \$(cat \$D/\$f) 2>/dev/null || true
  done
"

date -u '+END_UTC=%Y-%m-%dT%H:%M:%SZ' | tee -a "$RESULT/run-timing.txt"

say "collect artifacts"
mkdir -p "$ARCH/broker-vm"
for n in 1 2 3 4 5; do
  mkdir -p "$ARCH/publisher-$n" "$ARCH/subscriber-$n"
done

cp -a "$RESULT"/. "$ARCH/publisher-1/"
for n in 2 3 4 5; do
  ip="$(pub_ip "$n")"
  scp -r ogawa@"$ip":~/aomqtt-results/"$RUN"/. "$ARCH/publisher-$n/"
done
for n in 1 2 3 4 5; do
  ip="$(sub_ip "$n")"
  scp -r ogawa@"$ip":~/aomqtt-results/"$RUN"/. "$ARCH/subscriber-$n/"
done
scp -r ogawa@"$BROKER":~/aomqtt-results/"$RUN"/. "$ARCH/broker-vm/"

say "quick validation"
python3 - "$ARCH" "$RUN" "$EXPECTED_TOTAL" "$EXPECTED_OBSERVATIONS" <<'PY'
import csv, math, re, statistics, sys
from pathlib import Path

A=Path(sys.argv[1])
run=sys.argv[2]
expected_total=int(sys.argv[3])
expected_observations=int(sys.argv[4])
ok=True

def truth(v):
    return str(v).strip().lower() in {"1","true","yes","y"}

def norm(v):
    return (v or "").replace(r"\:", ":")

def pct(values,q):
    xs=sorted(values)
    if not xs:
        return float("nan")
    k=(len(xs)-1)*q
    lo=int(math.floor(k))
    hi=min(lo+1,len(xs)-1)
    if lo==hi:
        return xs[lo]
    return xs[lo]+(xs[hi]-xs[lo])*(k-lo)

expected=set()
first_ts=[]

for n in range(1,6):
    p=A/f"publisher-{n}"/f"publisher-{n}-metrics.csv"
    with p.open(newline="") as f:
        rows=list(csv.DictReader(f))

    mids={norm(r.get("message_id","")) for r in rows if r.get("message_id")}
    exp={f"e3-mc4-plain-pub{n}:{run}:{i}" for i in range(6000)}
    expected |= exp

    succ=sum(truth(r.get("success")) for r in rows)
    missing=len(exp-mids)
    unexpected=len(mids-exp)

    ts=[]
    for r in rows:
        try:
            ts.append(float(r.get("publisher_timestamp","")))
        except Exception:
            pass
    if ts:
        first_ts.append((n,min(ts)))

    log=(A/f"publisher-{n}"/f"publisher-{n}.log").read_text(errors="replace")
    m=re.search(r"pacing_deadline_miss:\s*(\d+)",log)
    misses=int(m.group(1)) if m else -1

    rp=A/f"publisher-{n}"/f"publisher-{n}-proc-resource.csv"
    rlines=sum(1 for _ in rp.open())

    print(
        f"publisher-{n}: physical_rows={len(rows)} unique={len(mids)} "
        f"success={succ} missing={missing} unexpected={unexpected} "
        f"pacing_deadline_miss={misses} resource_lines={rlines}"
    )

    ok &= (
        len(rows)==6000 and
        len(mids)==6000 and
        succ==6000 and
        missing==0 and
        unexpected==0 and
        misses==0 and
        rlines>=50
    )

print(f"expected_union={len(expected)}")
ok &= (len(expected)==expected_total)

total_raw=0
total_unique=0
total_duplicates=0

for n in range(1,6):
    sp=A/f"subscriber-{n}"/f"subscriber-{n}-delivery.csv"
    with sp.open(newline="") as f:
        rows=list(csv.DictReader(f))

    mids={norm(r.get("message_id","")) for r in rows if r.get("message_id")}
    parse_errors=sum(bool((r.get("parse_error") or "").strip()) for r in rows)
    duplicates=sum(truth(r.get("duplicate")) for r in rows)
    missing=len(expected-mids)
    unexpected=len(mids-expected)

    lat=[]
    seen=set()
    for r in rows:
        mid=norm(r.get("message_id",""))
        if not mid or mid in seen or truth(r.get("duplicate")):
            continue
        seen.add(mid)
        try:
            v=float(r.get("delivery_latency_ms",""))
        except Exception:
            continue
        if v >= 0:
            lat.append(v)

    rp=A/f"subscriber-{n}"/f"subscriber-{n}-proc-resource.csv"
    resource_lines=sum(1 for _ in rp.open())

    print(
        f"subscriber-{n}: raw={len(rows)} unique={len(mids)} "
        f"duplicates={duplicates} parse_errors={parse_errors} "
        f"missing={missing} unexpected={unexpected} "
        f"resource_lines={resource_lines}"
    )

    ok &= (
        len(rows)==expected_total and
        len(mids)==expected_total and
        duplicates==0 and
        parse_errors==0 and
        missing==0 and
        unexpected==0 and
        resource_lines>=50
    )

    if lat:
        print(
            f"subscriber-{n} latency_ms: "
            f"n={len(lat)} mean={statistics.mean(lat):.6f} "
            f"p95={pct(lat,0.95):.6f} "
            f"p99={pct(lat,0.99):.6f} "
            f"max={max(lat):.6f}"
        )
        ok &= (len(lat)==expected_total)
    else:
        print(f"subscriber-{n} latency_ms: n=0")
        ok=False

    total_raw += len(rows)
    total_unique += len(mids)
    total_duplicates += duplicates

print(
    f"subscriber_all: raw={total_raw} "
    f"unique_observations={total_unique} duplicates={total_duplicates}"
)
print(f"expected_subscriber_unique_observations={expected_observations}")
ok &= (
    total_unique==expected_observations and
    total_duplicates==0
)

bp=A/"broker-vm"/"broker-proc-resource.csv"
broker_resource_lines=sum(1 for _ in bp.open())
print(f"broker_resource_lines={broker_resource_lines}")
ok &= broker_resource_lines>=50

if len(first_ts)==5:
    vals=[x[1] for x in first_ts]
    spread_ms=(max(vals)-min(vals))*1000.0
    print(f"publisher_first_metric_timestamp_spread_ms={spread_ms:.3f}")
else:
    print("publisher_first_metric_timestamp_spread_ms=NA")
    ok=False

print("QUICK_VALIDATION=" + ("PASS" if ok else "FAIL"))
sys.exit(0 if ok else 3)
PY

say "archive checksums"
cd "$ARCH"
find . -type f ! -name SHA256SUMS.txt ! -name SHA256SUMS.txt.sha256 -print0 \
  | sort -z | xargs -0 sha256sum > SHA256SUMS.txt
sha256sum SHA256SUMS.txt > SHA256SUMS.txt.sha256

cd "$HOME/aomqtt-experiment-archives"
tar -czf "$RUN.tar.gz" "$RUN"
sha256sum "$RUN.tar.gz" > "$RUN.tar.gz.sha256"

say "final"
for n in 1 2 3 4 5; do
  echo "===== publisher-$n summary ====="
  grep -E \
    "logical messages:|total MQTT messages:|success:|failed:|avg_complete_ms:|p95_complete_ms:|pacing_mode:|pacing_deadline_miss:|pacing_late_max_ms:" \
    "$ARCH/publisher-$n/publisher-$n.log" | tail -n 9 || true
done

for n in 1 2 3 4 5; do
  echo "===== subscriber-$n summary ====="
  tail -n 12 "$ARCH/subscriber-$n/subscriber-$n.log" || true
done

echo "===== timing ====="
cat "$RESULT/run-timing.txt"

echo "===== archive SHA256 ====="
cat "$HOME/aomqtt-experiment-archives/$RUN.tar.gz.sha256"

SUCCESS=1
echo "MC4 Plain MQTT $REP completed"
